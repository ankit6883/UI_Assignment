import { Component, OnInit } from '@angular/core';
import { GetUserInfoService } from "../get-user-info.service";

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  userInfo=[];
  welcomeTxt: string = `Welcome to party!`;
  constructor(private _getuserInfo:GetUserInfoService) { }

  ngOnInit() {
   this._getuserInfo.getEmployees().subscribe(data=> {
     console.log(data.nodes[0].id);
     this.userInfo = data.nodes;
   })
  }

  getColor(color:string){
    return color;
  }

}
