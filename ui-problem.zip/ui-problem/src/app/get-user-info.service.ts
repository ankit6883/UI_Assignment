import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import {IUser} from './users';

@Injectable({
  providedIn: 'root'
})
export class GetUserInfoService {

  constructor(private _http: HttpClient) {

   }
   
   getEmployees():Observable<any>{
        return this._http.get<any>('https://api.myjson.com/bins/114l3c',{ responseType: 'json' });
   }

}
